# THREE.js Earth scene

Watch the tutorial on [YouTube](https://youtu.be/FntV9iEJ0tU)

Earth texture maps: [PlanetPixelEmporium](https://planetpixelemporium.com/earth.html)